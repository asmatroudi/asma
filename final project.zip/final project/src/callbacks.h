#include <gtk/gtk.h>

void
on_buttongotoajouter_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttongotomodifier_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_checkbuttonprepa_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonfemme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonbusiness_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonhomme_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttoncycleing_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonaffichier_reclamation_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajouter_reclamation_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier_reclamation_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_closebutton2_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_closebutton3_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_closebutton4_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonrecherche_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
